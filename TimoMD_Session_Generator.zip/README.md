# Timo MD Session Generator

This is a simple WhatsApp pairing code generator for the Timo MD bot using Baileys Multi-Device.

## 🚀 Run

```
npm install
node index.js
```

Visit `/generate` endpoint to get your QR/pairing code.